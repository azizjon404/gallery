let images = document.querySelectorAll('.img-gallery img');
let wrapper = document.getElementById('wrapper');
let imgWrapper = document.getElementById('fullimg');
let close = document.querySelector('#wrapper span');

images.forEach((img) => {
    img.addEventListener('click', () => {
        wrapper.style.display = 'flex';
        imgWrapper.src = img.src;
    });
});

close.addEventListener('click', () => {
    wrapper.style.display = 'none';
});
